# frozen_string_literal: true

require 'super-critical/version'